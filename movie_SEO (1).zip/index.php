<?php
// index.php

// Inclure les fichiers nécessaires
include('functions.php');

// Afficher la liste des films
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Films</title>

    <!-- Lien vers le fichier CSS -->
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <!-- Barre de navigation -->
    <nav class="navbar">
        <ul class="nav-links">
            <li><a href="index.php">Liste des Films</a></li>
            <li><a href="create.php">Je suggere!</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="about.php">À propos</a></li>
        </ul>
    </nav>

    <div class="container index-page">
        <h1>FILM</h1>

        <a href="create.php" class="btn-retour" style="background-color: black;">Suggerer un nouveau film</a><br><br>

        <?php
        // Récupérer et afficher les films
        $films = getFilms();
        if (!empty($films)) {
            foreach ($films as $film) {
                echo "<div class='film-item'>";
                echo "<h3>" . $film['titre'] . "</h3>";
                echo "<p><strong>Année:</strong> " . $film['annee'] . "</p>";
                echo "<p><strong>Description:</strong> " . $film['description'] . "</p>";
                echo "<img src='" . $film['image_url'] . "' alt='" . $film['titre'] . "'><br>";
                echo "<a href='detail.php?id=" . $film['id'] . "' class='btn-retour'>Détails</a>"; // Lien vers la page de détails
                echo "</div><br>";
            }
        } else {
            echo "<p>Aucun film trouvé.</p>";
        }
        ?>
    </div>
</body>

</html>