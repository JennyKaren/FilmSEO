<?php
// detail.php

// Inclure les fichiers nécessaires
include('functions.php');

// Vérifier si l'id est passé dans l'URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Récupérer les détails du film
    $films = getFilms();
    $filmDetails = null;
    foreach ($films as $film) {
        if ($film['id'] == $id) {
            $filmDetails = $film;
            break;
        }
    }
?>

    <!DOCTYPE html>
    <html lang="fr">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Détails du Film</title>

        <link rel="stylesheet" href="style.css"> <!-- Lien vers le fichier CSS externe -->
    </head>

    <body>
        <!-- Navbar -->
    <nav class="navbar">
        <ul class="nav-links">
            <li><a href="index.php">Liste des Films</a></li>
            <li><a href="create.php">Je suggere!</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="about.php">À propos</a></li>
        </ul>
    </nav>
        <div class="container">
            <?php
            if ($filmDetails) {
                // Affichage des détails du film avec la classe 'detail-film' pour le style
                echo "<div class='detail-film'>";
                echo "<h2>" . $filmDetails['titre'] . "</h2>";
                echo "<p><strong>Année:</strong> " . $filmDetails['annee'] . "</p>";
                echo "<p><strong>Description:</strong> " . $filmDetails['description'] . "</p>";
                echo "<img src='" . $filmDetails['image_url'] . "' alt='" . $filmDetails['titre'] . "'><br>";
                echo "</div>";
            } else {
                echo "<p>Film non trouvé.</p>";
            }
            ?>

            <!-- Ajout d'un bouton retour -->
            <a href="index.php" class="btn-retour">Retour à la liste</a>
        </div>
    </body>

    </html>

<?php
} else {
    echo "<p>ID de film manquant.</p>";
}
?>