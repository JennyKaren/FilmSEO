<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar">
        <ul class="nav-links">
            <li><a href="index.php">Liste des Films</a></li>
            <li><a href="create.php">Je suggere!</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="about.php">À propos</a></li>
        </ul>
    </nav>
    <div class="about-page">
        <h1>À Propos</h1>
        <div class="about-content">
            <p>Bienvenue sur notre site ! Nous sommes passionnés par le cinéma et nous voulons partager cette passion avec vous. Découvrez nos critiques, recommandations et bien plus encore.</p>
            <img src="assets/about.jpg" alt="Notre équipe" class="about-image">
        </div>
    </div>

</body>

</html>