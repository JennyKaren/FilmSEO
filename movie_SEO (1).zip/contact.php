<!-- contact.php -->

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>

    <!-- Lien vers le fichier CSS -->
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar">
        <ul class="nav-links">
            <li><a href="index.php">Liste des Films</a></li>
            <li><a href="create.php">Je suggere!</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="about.php">À propos</a></li>
        </ul>
    </nav>


    <div class="container contact-page">
        <h1>Contactez-Nous</h1>

        <div class="contact-info">
            <div class="info-section">
                <h2>Nos Coordonnées</h2>
                <p><strong>Email:</strong> film@gmail.com</p>
                <p><strong>Téléphone:</strong> +33 1 23 45 67 89</p>
                <p><strong>Adresse:</strong> 123 Rue de Andoharanofotsy, 101, Madagascar</p>
            </div>

            <div class="info-section">
                <h2>Suivez-Nous</h2>
                <p>Restez connectés sur nos réseaux sociaux:</p>
                <div class="social-media">
                    <a href="#" target="_blank">Facebook</a>
                    <a href="#" target="_blank">Twitter</a>
                    <a href="#" target="_blank">Instagram</a>
                </div>
            </div>
        </div>

        <div class="image-gallery">
            <img src="assets/netflix.jpg" class="contact-img">
            <img src="assets/film.jpg" class="contact-img">
        </div>

        <div class="contact-form">
            <h2>Envoyer un Message</h2>
            <form method="POST" action="#">
                <label for="name">Nom :</label>
                <input type="text" id="name" name="name" required>

                <label for="email">Email :</label>
                <input type="email" id="email" name="email" required>

                <label for="message">Message :</label>
                <textarea id="message" name="message" required></textarea>

                <input type="submit" value="Envoyer">
            </form>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Votre Site | Tous droits réservés</p>
    </footer>
</body>

</html>