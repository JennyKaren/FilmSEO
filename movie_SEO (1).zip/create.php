<!-- create.php -->

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Je suggere!</title>

    <link rel="stylesheet" href="style.css"> <!-- Lien vers le fichier CSS externe -->
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar">
        <ul class="nav-links">
            <li><a href="index.php">Liste des Films</a></li>
            <li><a href="create.php">Je suggere!</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="about.php">À propos</a></li>
        </ul>
    </nav>
    <div class="container">
        <h1>Suggerer un Film</h1>

        <!-- Formulaire d'ajout de film avec la classe 'create-film' pour le style -->
        <form method="POST" action="ajouter-film.php" class="create-film">
            <label for="titre">Titre :</label><br>
            <input type="text" id="titre" name="titre" required><br><br>

            <label for="annee">Année :</label><br>
            <input type="number" id="annee" name="annee" required><br><br>

            <label for="description">Description :</label><br>
            <textarea id="description" name="description" required></textarea><br><br>

            <label for="image_url">URL de l'image :</label><br>
            <!-- Liste déroulante pour choisir l'image -->
            <select id="image_url" name="image_url" required>
                <option value="assets/default.jpg">image par defaut</option>
            </select><br><br>

            <input type="submit" value="Ajouter">
        </form>
    </div>
</body>

</html>